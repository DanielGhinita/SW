const http = require('http');
const fs = require('fs');
const path = require('path');
const sqlite3 = require('sqlite3').verbose();
const multer = require('multer');

// Conectare la baza de date SQLite
const db = new sqlite3.Database('./users.db', (err) => {
  if (err) {
    console.error('Eroare la deschiderea bazei de date:', err.message);
  } else {
    console.log('Conexiune reușită la baza de date SQLite.');
  }
});

// Creare tabel dacă nu există
db.run(`CREATE TABLE IF NOT EXISTS users (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  username TEXT,
  email TEXT,
  password TEXT,
  firstName TEXT,
  lastName TEXT,
  displayName TEXT,
  website TEXT,
  profilePicture TEXT
)`);

// Configurare multer pentru a salva fișierele încărcate
const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    cb(null, 'uploads/'); // Folderul unde vor fi salvate fișierele
  },
  filename: (req, file, cb) => {
    cb(null, Date.now() + path.extname(file.originalname)); // Nume de fișier unic
  }
});
const upload = multer({ storage: storage });

// Setare port
const port = 3000;

// Funcție pentru a trimite răspunsuri cu fișierele statice
const serveStaticFile = (res, filePath, contentType, statusCode = 200) => {
  fs.readFile(filePath, (err, data) => {
    if (err) {
      res.writeHead(500, { 'Content-Type': 'text/plain' });
      res.end('500 - Eroare internă a serverului');
    } else {
      res.writeHead(statusCode, { 'Content-Type': contentType });
      res.end(data);
    }
  });
};

// Creare server HTTP
const server = http.createServer((req, res) => {
  if (req.method === 'GET') {
    // Ruta principală pentru pagina HTML
    if (req.url === '/' || req.url === '/index.html') {
      serveStaticFile(res, path.join(__dirname, 'views', 'index.html'), 'text/html');
    } 
    // Servirea fișierelor CSS
    else if (req.url.match(/\.css$/)) {
      serveStaticFile(res, path.join(__dirname, 'public', req.url), 'text/css');
    } 
    // Servirea fișierelor JS
    else if (req.url.match(/\.js$/)) {
      serveStaticFile(res, path.join(__dirname, 'public', req.url), 'application/javascript');
    } 
    // Dacă fișierul nu este găsit
    else {
      res.writeHead(404, { 'Content-Type': 'text/plain' });
      res.end('404 - Resursa nu a fost găsită');
    }
  } else if (req.method === 'POST' && req.url === '/register') {
    // Adunare datele trimise din formular, inclusiv fișierul
    upload.single('profilePicture')(req, res, (err) => {
      if (err) {
        res.writeHead(500, { 'Content-Type': 'text/plain' });
        res.end('500 - Eroare la încărcarea fișierului');
        return;
      }

      const { username, email, password, firstName, lastName, displayName, website } = req.body;
      const profilePicture = req.file ? req.file.path : null;

      console.log('Datele primite din formular:', { ...req.body, profilePicture }); // Debug

      // Validare minimă
      if (!username || !email || !password || !firstName || !lastName) {
        res.writeHead(400, { 'Content-Type': 'text/plain' });
        res.end('Datele trimise nu sunt valide.');
        return;
      }

      // Salvarea datelor în baza de date
      const sql = `INSERT INTO users (username, email, password, firstName, lastName, displayName, website, profilePicture)
                   VALUES (?, ?, ?, ?, ?, ?, ?, ?)`;

      db.run(sql, [username, email, password, firstName, lastName, displayName, website, profilePicture], (err) => {
        if (err) {
          console.error('Eroare la inserarea datelor în baza de date:', err.message);
          res.writeHead(500, { 'Content-Type': 'text/plain' });
          res.end('500 - Eroare la salvarea datelor în baza de date');
        } else {
          res.writeHead(200, { 'Content-Type': 'text/plain' });
          res.end('Datele au fost salvate cu succes');
        }
      });
    });
  }
});

// Pornirea serverului
server.listen(port, () => {
  console.log(`Serverul rulează pe http://localhost:${port}`);
});
