const http = require('http');
const url = require('url');
const fs = require('fs');
const path = require('path');
const sqlite3 = require('sqlite3').verbose();
const multer = require('multer');
const { parse } = require('querystring');

const db = new sqlite3.Database('./users.db', (err) => {
  if (err) {
    console.error('Eroare la deschiderea bazei de date:', err.message);
  } else {
    console.log('Conexiune reușită la baza de date SQLite.');
  }
});

db.run(`CREATE TABLE IF NOT EXISTS users (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  username TEXT,
  email TEXT,
  password TEXT,
  firstName TEXT,
  lastName TEXT,
  displayName TEXT,
  website TEXT,
  profilePicture TEXT
)`);

const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    cb(null, 'uploads/');
  },
  filename: (req, file, cb) => {
    cb(null, Date.now() + path.extname(file.originalname));
  }
});
const upload = multer({ storage: storage });

const port = 3000;

function logRequest(req, statusCode) {
  const logEntry = `[${new Date().toISOString()}] ${req.method} ${req.url} ${statusCode} - IP: ${req.socket.remoteAddress}\n`;
  fs.appendFile('log.txt', logEntry, (err) => {
    if (err) console.error('Eroare la scrierea în fișierul de jurnal:', err);
  });
}

const serveStaticFile = (res, filePath, contentType, statusCode = 200) => {
  fs.readFile(filePath, (err, data) => {
    if (err) {
      res.writeHead(500, { 'Content-Type': 'text/plain' });
      res.end('500 - Eroare internă a serverului');
      logRequest(res, 500);
    } else {
      res.writeHead(statusCode, { 'Content-Type': contentType });
      res.end(data);
      logRequest(res, statusCode);
    }
  });
};

const server = http.createServer((req, res) => {
  const parsedUrl = url.parse(req.url, true);

  if (req.method === 'GET') {
    if (req.url === '/' || req.url === '/index.html') {
      serveStaticFile(res, path.join(__dirname, 'views', 'index.html'), 'text/html');
    } else if (req.url.match(/\.css$/)) {
      serveStaticFile(res, path.join(__dirname, 'public', req.url), 'text/css');
    } else if (req.url.match(/\.js$/)) {
      serveStaticFile(res, path.join(__dirname, 'public', req.url), 'application/javascript');
    } else if (parsedUrl.pathname === '/search') {
      const searchName = parsedUrl.query.searchName;

      if (!searchName) {
        res.writeHead(400, { 'Content-Type': 'text/plain' });
        res.end('Parametru de căutare lipsă.');
        logRequest(req, 400);
        return;
      }

      const sql = `SELECT * FROM users WHERE username LIKE ?`;
      db.all(sql, [`%${searchName}%`], (err, rows) => {
        if (err) {
          console.error('Eroare la interogarea bazei de date:', err.message);
          res.writeHead(500, { 'Content-Type': 'text/plain' });
          res.end('Eroare la interogarea bazei de date.');
          logRequest(req, 500);
          return;
        }

        let htmlContent = `
        <html>
          <head>
            <title>Rezultate căutare</title>
          </head>
          <body>
            <h2>Rezultate căutare pentru: <strong>${searchName}</strong></h2>
            <ul>
        `;
        
        rows.forEach(row => {
          htmlContent += `<li>${row.username} - ${row.email}</li>`;
        });
        
        htmlContent += `
            </ul>
          </body>
        </html>
        `;

        res.writeHead(200, { 'Content-Type': 'text/html' });
        res.end(htmlContent);
        logRequest(req, 200);
      });
    } else {
      res.writeHead(404, { 'Content-Type': 'text/plain' });
      res.end('404 - Resursa nu a fost găsită');
      logRequest(req, 404);
    }
  } else if (req.method === 'POST') {
    if (parsedUrl.pathname === '/register') {
      let body = '';
    
      req.on('data', (chunk) => {
        body += chunk.toString();
      });
    
      req.on('end', () => {
        const data = parse(body);
    
        const { username, email, password, firstName, lastName, displayName, website } = data;
        const profilePicture = 'uploads/default.png'; // Default picture
    
        const sql = `INSERT INTO users (username, email, password, firstName, lastName, displayName, website, profilePicture) VALUES (?, ?, ?, ?, ?, ?, ?, ?)`;
    
        db.run(sql, [username, email, password, firstName, lastName, displayName, website, profilePicture], function (err) {
          if (err) {
            console.error('Eroare la inserarea în baza de date:', err.message);
            res.writeHead(500, { 'Content-Type': 'text/plain' });
            res.end('Eroare la înregistrare.');
            logRequest(req, 500);
          } else {
            res.writeHead(200, { 'Content-Type': 'text/plain' });
            res.end('Înregistrare reușită.');
            logRequest(req, 200);
          }
        });
      });
    }
    else {
      res.writeHead(405, { 'Content-Type': 'text/plain' });
      res.end('Metodă neacceptată');
      logRequest(req, 405);
    }
  } else {
    res.writeHead(405, { 'Content-Type': 'text/plain' });
    res.end('Metodă neacceptată');
    logRequest(req, 405);
  }
});

server.listen(port, () => {
  console.log(`Serverul rulează pe portul ${port}`);
});
