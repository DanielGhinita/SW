from flask import Flask, request, jsonify, render_template
from flask_cors import CORS
import logging
from datetime import datetime

app = Flask(__name__)
CORS(app)

# Configurare log-uri
logging.basicConfig(filename='server.log', level=logging.DEBUG,
                    format='%(asctime)s %(levelname)s %(message)s')

# Listă pentru stocarea cererilor
requests_log = []

# Funcție pentru a salva payloadurile în fișierul payloads.txt
def log_payload(payload):
    with open("payloads.txt", "a") as f:
        f.write(f"{datetime.now().strftime('%Y-%m-%d %H:%M:%S')} - Payload: {payload}\n")

@app.route('/api/date', methods=['GET', 'POST'])
def api_date():
    timestamp = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    if request.method == 'POST':
        # Preia datele primite și le salvează
        data = request.get_json(silent=True) or {}
        logging.info(f"Received POST data: {data}")
        log_payload(data)  # Salvăm payloadul în fișierul payloads.txt
        requests_log.append({'method': 'POST', 'data': data, 'time': timestamp})
        return {"message": "Date primite cu succes!", "data": data, "time": timestamp}, 200
    elif request.method == 'GET':
        # Preia cererile stocate
        logging.info("Received GET request")
        requests_log.append({'method': 'GET', 'data': None, 'time': timestamp})
        return {"message": "Hello World!", "time": timestamp}, 200

@app.route('/requests', methods=['GET'])
def show_requests():
    # Returnează toate cererile sub formă de JSON
    return jsonify(requests_log), 200

# FRONTEND  
@app.route('/', methods=['GET'])
def home():
    return '''
    <!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Vizualizare Cereri</title>
        <style>
            body {
                font-family: Arial, sans-serif;
                margin: 0;
                padding: 0;
                display: flex;
                height: 100vh;
            }
            #sidebar {
                width: 30%;
                background-color: #f4f4f4;
                padding: 10px;
                border-right: 2px solid #ccc;
                overflow-y: auto;
            }
            #main {
                flex-grow: 1;
                padding: 20px;
            }
            #requests-list {
                list-style-type: none;
                padding: 0;
            }
            #requests-list li {
                padding: 10px;
                margin: 5px 0;
                background: #ddd;
                border-radius: 5px;
            }
        </style>
    </head>
    <body>
        <div id="sidebar">
            <h2>Cereri primite</h2>
            <ul id="requests-list"></ul>
        </div>
        <div id="main">
            <h1>Vizualizare Cereri</h1>
            <p>Cereri primite în server. Această listă se actualizează automat.</p>
            <p><strong>Ultima cerere:</strong> <span id="latest-request"></span></p>
        </div>
        <script>
            // Fetch pentru a obține cererile de la server
            async function fetchRequests() {
                const response = await fetch('/requests');
                const data = await response.json();
                const list = document.getElementById('requests-list');
                const latest = document.getElementById('latest-request');
                list.innerHTML = '';
                data.forEach((req, index) => {
                    const listItem = document.createElement('li');
                    listItem.textContent = `#${index + 1}: ${req.time} - Method=${req.method}, Data=${JSON.stringify(req.data)}`;
                    list.appendChild(listItem);
                });
                if (data.length > 0) {
                    const lastRequest = data[data.length - 1];
                    latest.textContent = `${lastRequest.time} - Method=${lastRequest.method}, Data=${JSON.stringify(lastRequest.data)}`;
                } else {
                    latest.textContent = 'Nicio cerere încă.';
                }
            }

            // Actualizare periodică
            setInterval(fetchRequests, 2000); // Actualizare la fiecare 2 secunde
            fetchRequests(); // Prima încărcare
        </script>
    </body>
    </html>
    '''

if __name__ == '__main__':
    app.run(debug=True, port=5000)
