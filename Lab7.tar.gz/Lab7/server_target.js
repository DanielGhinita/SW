const express = require('express');
const bodyParser = require('body-parser');
const app = express();
const port = 4567;

// Setează motorul de templating EJS
app.set('view engine', 'ejs');
app.set('views', './views');  // Asigură-te că acest director există

app.use(bodyParser.urlencoded({ extended: true }));

// Simulăm o "bază de date" simplă pentru utilizatori
const users = [];

// Ruta pentru afișarea utilizatorilor
app.get('/', (req, res) => {
  res.render('index', { users: users });
});

// Ruta pentru crearea utilizatorilor
app.post('/create-user', (req, res) => {
  const username = req.body.username;
  users.push(username); // Adăugăm numele în lista utilizatorilor
  res.redirect('/');
});

app.listen(port, () => {
  console.log(`Serverul țintă rulează la http://localhost:${port}`);
});
