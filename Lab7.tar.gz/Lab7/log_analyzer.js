// node log_analyzer.js 4xx
// node log_analyzer.js unique
// node log_analyzer.js realtime

const fs = require('fs');
const readline = require('readline');
const path = require('path');
const tail = require('tail').Tail;

// Funcția de analiză pentru loguri
function analyzeLogs(logFilePath, option) {
  switch (option) {
    case '4xx':
      show4xxErrors(logFilePath);
      break;
    case 'unique':
      showUniqueUrls(logFilePath);
      break;
    case 'realtime':
      monitorLogsInRealTime(logFilePath);
      break;
    default:
      console.log('Argument invalid. Utilizați: 4xx, unique, realtime');
  }
}

// 1. Afișarea URL-urilor și IP-urilor pentru coduri de eroare 4xx
function show4xxErrors(logFilePath) {
  const rl = readline.createInterface({
    input: fs.createReadStream(logFilePath),
    output: process.stdout,
    terminal: false
  });

  rl.on('line', (line) => {
    const logEntry = parseLogLine(line);
    if (logEntry && logEntry.statusCode >= 400 && logEntry.statusCode < 500) {
      console.log(`IP: ${logEntry.ip}, URL: ${logEntry.url}, Status: ${logEntry.statusCode}`);
    }
  });

  rl.on('close', () => {
    console.log('Analiza logurilor de erori 4xx s-a încheiat.');
  });
}

// 2. Afișarea URL-urilor unice accesate și numărul total de accesări
function showUniqueUrls(logFilePath) {
  const urlMap = new Map();

  const rl = readline.createInterface({
    input: fs.createReadStream(logFilePath),
    output: process.stdout,
    terminal: false
  });

  rl.on('line', (line) => {
    const logEntry = parseLogLine(line);
    if (logEntry) {
      const key = `${logEntry.url} - Status: ${logEntry.statusCode}`;
      urlMap.set(key, (urlMap.get(key) || 0) + 1);
    }
  });

  rl.on('close', () => {
    console.log('Lista URL-urilor unice accesate:');
    for (const [url, count] of urlMap.entries()) {
      console.log(`${url}, Număr accesări: ${count}`);
    }
  });
}

// 3. Monitorizare log în timp real pentru erori 4xx
function monitorLogsInRealTime(logFilePath) {
  const logTail = new tail(logFilePath);

  logTail.on('line', (line) => {
    const logEntry = parseLogLine(line);
    if (logEntry && logEntry.statusCode >= 400 && logEntry.statusCode < 500) {
      console.log(`[REALTIME] IP: ${logEntry.ip}, URL: ${logEntry.url}, Status: ${logEntry.statusCode}`);
    }
  });

  logTail.on('error', (error) => {
    console.error('Eroare la monitorizarea log-urilor:', error);
  });
}

// Funcție pentru parsarea unei linii de log în informații utile (ip, url, cod de status)
function parseLogLine(line) {
  const logRegex = /(\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}) - - \[.*?\] "GET (.*?) HTTP\/1\.[01]" (\d{3})/;
  const match = logRegex.exec(line);

  if (match) {
    return {
      ip: match[1],
      url: match[2],
      statusCode: parseInt(match[3], 10),
    };
  }
  return null;
}

// Funcția principală care preia argumentele de la linia de comandă
const logFilePath = path.join(__dirname, 'log.txt');
const option = process.argv[2];  // Argumentul pentru analiza dorită

analyzeLogs(logFilePath, option);
