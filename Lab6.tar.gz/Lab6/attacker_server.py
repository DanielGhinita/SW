from flask import Flask, request
import logging

# Configurare log pentru salvarea în fișier
logging.basicConfig(filename='server.log', level=logging.DEBUG, 
                    format='%(asctime)s %(levelname)s %(message)s')

app = Flask(__name__)

# Configurare logger
logging.basicConfig(filename='server.log', level=logging.DEBUG, format='%(asctime)s %(message)s')


@app.route('/api/date', methods=['GET', 'POST'])
def api_date():
    # Înregistrare detalii ale cererii în log
    data = request.json
    app.logger.info(f'Date primite de la victimă: {data}') 
    app.logger.info("Metoda HTTP: %s", request.method)
    app.logger.info("Header-ele HTTP: %s", request.headers)
    app.logger.info("Parametri URL (query params): %s", request.args)
    app.logger.info("Conținut formular (body): %s", request.form)
    app.logger.info("Fișiere încărcate: %s", request.files)
    app.logger.info("Valori combinate din request.args și request.form: %s", request.values)
    app.logger.info("Conținut JSON (dacă există): %s", request.json)
    app.logger.info("Cookie-urile trimise: %s", request.cookies)

    # Returnăm un mesaj pentru confirmare
    return 'Data received', 200

if __name__ == '__main__':
    app.run(port=5000)
