const express = require('express');
const app = express();
const port = 4567;

// Configurăm EJS pentru a permite HTML nesigur
app.set('view engine', 'ejs');
app.set('views', './views');

// Ruta pentru căutare
app.get('/cauta', (req, res) => {
  const q = req.query.q || '';
  res.render('cauta', { qq: q });
});

app.listen(port, () => {
  console.log(`Serverul țintă rulează la http://localhost:${port}`);
});
