const express = require("express");
const bodyParser = require("body-parser");
const fs = require('fs');
const path = require('path');
const sqlite3 = require('sqlite3').verbose();
const multer = require('multer');

// Creare aplicație Express
const app = express();

// Conectare la baza de date SQLite
const db = new sqlite3.Database('./users.db', (err) => {
  if (err) {
    console.error('Eroare la deschiderea bazei de date:', err.message);
  } else {
    console.log('Conexiune reușită la baza de date SQLite.');
  }
});

// Creare tabel dacă nu există
db.run(`CREATE TABLE IF NOT EXISTS users (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  username TEXT,
  email TEXT,
  password TEXT,
  firstName TEXT,
  lastName TEXT,
  displayName TEXT,
  website TEXT,
  profilePicture TEXT
)`);

// Configurare multer pentru a salva fișierele încărcate
const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    cb(null, 'uploads/');
  },
  filename: (req, file, cb) => {
    cb(null, Date.now() + path.extname(file.originalname));
  }
});
const upload = multer({ storage: storage });

// Setare port
const port = 3000;

// Funcție pentru a trimite răspunsuri cu fișierele statice
app.use(bodyParser.urlencoded({ extended: true }));
app.use(express.static("public"));

// Ruta pentru pagina principală
app.get("/main.html", (req, res) => {
  res.sendFile(path.join(__dirname, "views", "main.html"));
});

// Ruta pentru căutare utilizatori după nume
app.get("/cauta", (req, res) => {
  const nume = req.query.nume;

  // Utilizare parametrizare pentru prevenirea SQL injection
  const sql = `SELECT * FROM users WHERE firstName = ? OR lastName = ?`;
  db.all(sql, [nume, nume], (err, rows) => {
    if (err) {
      res.status(500).send("Eroare la interogarea bazei de date.");
      return;
    }
    res.json(rows.length > 0 ? rows : { mesaj: "Nu s-au găsit utilizatori." });
  });
});

// Ruta pentru înregistrare utilizatori
app.post('/register', upload.single('profilePicture'), (req, res) => {
  const { username, email, password, firstName, lastName, displayName, website } = req.body;
  const profilePicture = req.file ? req.file.path : null;

  if (!username || !email || !password || !firstName || !lastName) {
    res.status(400).send('Datele trimise nu sunt valide.');
    return;
  }

  const sql = `INSERT INTO users (username, email, password, firstName, lastName, displayName, website, profilePicture)
               VALUES (?, ?, ?, ?, ?, ?, ?, ?)`;

  db.run(sql, [username, email, password, firstName, lastName, displayName, website, profilePicture], (err) => {
    if (err) {
      console.error('Eroare la inserarea datelor în baza de date:', err.message);
      res.status(500).send('500 - Eroare la salvarea datelor în baza de date');
    } else {
      res.status(200).send('Datele au fost salvate cu succes');
    }
  });
});

// Pornirea serverului
const server = app.listen(port, () => {
  console.log(`Serverul rulează pe http://localhost:${port}`);
});
