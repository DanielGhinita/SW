document.getElementById('registrationForm').addEventListener('submit', function(event) {
  event.preventDefault(); // Prevenim submiterea formularului

  let isValid = true;

  const username = document.getElementById('username').value;
  const email = document.getElementById('email').value;
  const password = document.getElementById('password').value;
  const confirmPassword = document.getElementById('confirmPassword').value;
  const firstName = document.getElementById('firstName').value;
  const lastName = document.getElementById('lastName').value;
  const displayName = document.getElementById('displayName').value;
  const website = document.getElementById('website').value;

  // Validări
  const usernameRegex = /^[a-zA-Z0-9]{3,15}$/;
  if (!usernameRegex.test(username)) {
    alert("Numele utilizator trebuie să aibă între 3 și 15 caractere și să conțină doar litere și cifre.");
    isValid = false;
  }

  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  if (!emailRegex.test(email)) {
    alert("Introduceți un email valid.");
    isValid = false;
  }

  if (password.length < 6) {
    alert("Parola trebuie să aibă cel puțin 6 caractere.");
    isValid = false;
  }

  if (password !== confirmPassword) {
    alert("Parolele nu coincid.");
    isValid = false;
  }

  const nameRegex = /^[a-zA-Z]+$/;
  if (!nameRegex.test(firstName)) {
    alert("Prenumele trebuie să conțină doar litere.");
    isValid = false;
  }
  if (!nameRegex.test(lastName)) {
    alert("Numele trebuie să conțină doar litere.");
    isValid = false;
  }

  if (displayName.length < 3) {
    alert("Numele afișat trebuie să aibă cel puțin 3 caractere.");
    isValid = false;
  }

  if (website && !website.startsWith("http")) {
    alert("Introduceți un URL valid.");
    isValid = false;
  }

  if (isValid) {
    alert("Formularul a fost completat corect!");

    const formData = new FormData(this);

    fetch('/register', {
      method: 'POST',
      body: formData
    })
    .then(response => {
      if (response.ok) {
        return response.text();
      } else {
        throw new Error('Eroare la trimiterea formularului.');
      }
    })
    .then(data => {
      alert(data);
    })
    .catch(error => {
      alert('Eroare: ' + error.message);
    });
  }
});

document.getElementById("searchForm").addEventListener("submit", function(event) {
  event.preventDefault();
  const nume = document.getElementById("nume").value;

  fetch(`/cauta?nume=${encodeURIComponent(nume)}`)
    .then(response => response.json())
    .then(data => {
      const resultsDiv = document.getElementById("resultsContainer");
      resultsDiv.innerHTML = ""; // Clear previous results

      if (data.mesaj) {
        resultsDiv.textContent = data.mesaj;
      } else {
        data.forEach(user => {
          const userDiv = document.createElement("div");
          userDiv.className = "p-2 mb-2 bg-gray-300 rounded"; // Stilizare pentru rezultate
          userDiv.textContent = `${user.firstName} ${user.lastName}`;
          resultsDiv.appendChild(userDiv);
        });
      }
    })
    .catch(error => {
      document.getElementById("resultsContainer").textContent = "Eroare: " + error.message;
    });
});

